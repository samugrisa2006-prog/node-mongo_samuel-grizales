const mongoose = require('mongoose');
const Producto = require('../models/Producto');

const idNoValido = (res) =>
  res.status(400).json({
    ok: false,
    mensaje: 'ID de producto no válido (debe ser un ObjectId de 24 caracteres hexadecimales)',
  });

const crearProducto = async (req, res) => {
  try {
    const producto = new Producto(req.body);
    const productoGuardado = await producto.save();

    res.status(201).json({
      ok: true,
      mensaje: 'Producto creado correctamente',
      data: productoGuardado,
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      mensaje: 'Error al crear producto',
      error: error.message,
    });
  }
};

const obtenerProductos = async (req, res) => {
  try {
    const productos = await Producto.find();

    res.status(200).json({
      ok: true,
      total: productos.length,
      data: productos,
    });
  } catch (error) {
    res.status(500).json({
      ok: false,
      mensaje: 'Error al obtener productos',
      error: error.message,
    });
  }
};

const obtenerProductoPorId = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return idNoValido(res);
    }
    const producto = await Producto.findById(req.params.id).lean();

    if (!producto) {
      return res.status(404).json({
        ok: false,
        mensaje: 'Producto no encontrado',
      });
    }

    res.status(200).json({
      ok: true,
      data: producto,
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      mensaje: 'Error al buscar producto',
      error: error.message,
    });
  }
};

const actualizarProducto = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return idNoValido(res);
    }
    const productoActualizado = await Producto.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    ).lean();

    if (!productoActualizado) {
      return res.status(404).json({
        ok: false,
        mensaje: 'Producto no encontrado',
      });
    }

    res.status(200).json({
      ok: true,
      mensaje: 'Producto actualizado correctamente',
      data: productoActualizado,
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      mensaje: 'Error al actualizar producto',
      error: error.message,
    });
  }
};

const eliminarProducto = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return idNoValido(res);
    }
    const productoEliminado = await Producto.findByIdAndDelete(req.params.id).lean();

    if (!productoEliminado) {
      return res.status(404).json({
        ok: false,
        mensaje: 'Producto no encontrado',
      });
    }

    res.status(200).json({
      ok: true,
      mensaje: 'Producto eliminado correctamente',
      data: productoEliminado,
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      mensaje: 'Error al eliminar producto',
      error: error.message,
    });
  }
};

module.exports = {
  crearProducto,
  obtenerProductos,
  obtenerProductoPorId,
  actualizarProducto,
  eliminarProducto,
};
