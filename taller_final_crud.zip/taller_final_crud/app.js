
const express = require('express');
const dotenv = require('dotenv');
const conectarDB = require('./config/db');

dotenv.config();

if (!process.env.MONGODB_URI) {
  console.error('Error: define MONGODB_URI en el archivo .env');
  process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
  res.send('API CRUD con Node.js, Express y MongoDB funcionando');
});

app.use('/api/productos', require('./routes/producto.routes'));

// Vista en HTML por si el navegador integrado no muestra JSON en /api/productos
app.get('/lista-productos', async (req, res) => {
  try {
    const Producto = require('./models/Producto');
    const productos = await Producto.find().lean();
    const json = JSON.stringify(
      { ok: true, total: productos.length, data: productos },
      null,
      2
    );
    const safe = json
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    res.type('html').send(`<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Lista de productos</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 48rem; margin: 2rem auto; padding: 0 1rem; }
    pre { background: #f4f4f5; padding: 1rem; overflow: auto; font-size: 0.875rem; }
    a { color: #2563eb; }
  </style>
</head>
<body>
  <h1>Productos</h1>
  <p>JSON crudo en la API: <a href="/api/productos">/api/productos</a> (en Chrome/Edge suele verse bien; en el visor del editor a veces queda en blanco).</p>
  <pre>${safe}</pre>
</body>
</html>`);
  } catch (err) {
    res.status(500).type('html').send(`<p>Error: ${String(err.message)}</p>`);
  }
});

app.use((req, res) => {
  res.status(404).json({
    ok: false,
    mensaje: 'Ruta no encontrada',
  });
});

// Evita respuestas HTTP rotas si algo no controlado falla en una ruta async
app.use((err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }
  console.error(err);
  res.status(500).json({
    ok: false,
    mensaje: 'Error interno del servidor',
    error: err.message,
  });
});

const iniciar = async () => {
  await conectarDB();
  app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
  });
};

iniciar();
