// EJERCICIO 7 – Ventas por Vendedor
function procesarVentas(ventas) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(ventas)) return reject('Datos inválidos');
        let resumen = {};
        ventas.forEach(v => {
            if (!resumen[v.vendedor]) resumen[v.vendedor] = 0;
            resumen[v.vendedor] += v.monto;
        });
        let comisiones = {};
        let vendedorTop = null;
        let maxVenta = 0;
        for (let v in resumen) {
            comisiones[v] = resumen[v] * 0.05;
            if (resumen[v] > maxVenta) {
                maxVenta = resumen[v];
                vendedorTop = v;
            }
        }
        resolve({ resumen, comisiones, vendedorTop });
    });
}

module.exports = { procesarVentas };