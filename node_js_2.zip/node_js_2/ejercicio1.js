// EJERCICIO 1 – Procesar Nómina
function procesarNomina(empleados) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(empleados)) return reject('Datos inválidos');
        let empleadosProcesados = [];
        let empleadosError = [];
        let totalNomina = 0;
        empleados.forEach(e => {
            if (e.salarioBase > 0) {
                let valorHora = e.salarioBase / 240;
                let pagoHorasExtra = valorHora * 1.5 * e.horasExtra;
                let salarioBruto = e.salarioBase + pagoHorasExtra;
                let descuentoSalud = salarioBruto * 0.04;
                let salarioNeto = salarioBruto - descuentoSalud;
                empleadosProcesados.push({ ...e, valorHora, pagoHorasExtra, salarioBruto, descuentoSalud, salarioNeto });
                totalNomina += salarioNeto;
            } else {
                empleadosError.push(e);
            }
        });
        resolve({ empleadosProcesados, empleadosError, totalNomina });
    });
}

module.exports = { procesarNomina };