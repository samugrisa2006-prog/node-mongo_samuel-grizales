// EJERCICIO 10 – Proyectos y Presupuesto
function procesarProyectos(proyectos) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(proyectos)) return reject('Datos inválidos');
        let proyectosEnRiesgo = [];
        let porcentajeEjecucionGeneral = 0;
        let sumaPorcentajes = 0;
        proyectos.forEach(p => {
            let gastoTotal = p.gastos.reduce((a, b) => a + b, 0);
            let estado = gastoTotal > p.presupuesto ? 'Excedido' : 'Dentro del presupuesto';
            let porcentajeEjecucion = (gastoTotal / p.presupuesto) * 100;
            sumaPorcentajes += porcentajeEjecucion;
            if (estado === 'Excedido') proyectosEnRiesgo.push({ ...p, gastoTotal, estado, porcentajeEjecucion });
        });
        porcentajeEjecucionGeneral = sumaPorcentajes / proyectos.length;
        resolve({ proyectosEnRiesgo, porcentajeEjecucionGeneral });
    });
}

module.exports = { procesarProyectos };