// EJERCICIO 2 – Procesar Facturas con IVA
function procesarFacturas(facturas) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(facturas)) return reject('Datos inválidos');
        let facturasOK = [];
        let facturasError = [];
        let totalFacturado = 0;
        facturas.forEach(f => {
            if (f.productos && f.productos.length > 0) {
                let subtotal = f.productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
                let iva = subtotal * 0.19;
                let total = subtotal + iva;
                facturasOK.push({ ...f, subtotal, iva, total });
                totalFacturado += total;
            } else {
                facturasError.push(f);
            }
        });
        resolve({ facturasOK, facturasError, totalFacturado });
    });
}

module.exports = { procesarFacturas };