// EJERCICIO 6 – Préstamos Bancarios
function procesarPrestamos(prestamos) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(prestamos)) return reject('Datos inválidos');
        let prestamosOK = [];
        let prestamosError = [];
        let totalPrestado = 0;
        prestamos.forEach(p => {
            if (p.monto > 0) {
                let interesTotal = p.monto * p.tasa * p.plazo;
                let cuotaMensual = (p.monto + interesTotal) / p.plazo;
                prestamosOK.push({ ...p, interesTotal, cuotaMensual });
                totalPrestado += p.monto;
            } else {
                prestamosError.push(p);
            }
        });
        resolve({ prestamosOK, prestamosError, totalPrestado });
    });
}

module.exports = { procesarPrestamos };