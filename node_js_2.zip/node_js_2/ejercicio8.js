// EJERCICIO 8 – Consumo de Energía
function procesarEnergia(usuarios) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(usuarios)) return reject('Datos inválidos');
        let listaFacturas = [];
        let totalRecaudado = 0;
        usuarios.forEach(u => {
            if (u.consumo > 0) {
                let costo = u.consumo * u.tarifa;
                let subsidio = u.consumo < 150 ? costo * 0.10 : 0;
                let total = costo - subsidio;
                listaFacturas.push({ ...u, costo, subsidio, total });
                totalRecaudado += total;
            }
        });
        resolve({ listaFacturas, totalRecaudado });
    });
}

module.exports = { procesarEnergia };