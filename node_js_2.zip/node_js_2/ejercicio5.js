// EJERCICIO 5 – Inventario
function procesarInventario(productos) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(productos)) return reject('Datos inválidos');
        let listaReposicion = [];
        let costoTotalReposicion = 0;
        productos.forEach(p => {
            if (p.stockActual < p.stockMinimo) {
                let cantidad = p.stockMinimo - p.stockActual;
                let costo = cantidad * p.precio;
                listaReposicion.push({ ...p, cantidad, costo });
                costoTotalReposicion += costo;
            }
        });
        resolve({ listaReposicion, costoTotalReposicion });
    });
}

module.exports = { procesarInventario };