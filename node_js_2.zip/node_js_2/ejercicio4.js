// EJERCICIO 4 – Carrito de Compras
function procesarCarritos(carritos) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(carritos)) return reject('Datos inválidos');
        let ventasOK = [];
        let ventasError = [];
        let totalVentas = 0;
        carritos.forEach(c => {
            if (c.productos && c.productos.length > 0) {
                let subtotal = c.productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
                let envio = c.ciudad === 'Medellín' ? 10000 : 20000;
                let descuento = subtotal > 100000 ? subtotal * 0.05 : 0;
                let total = subtotal + envio - descuento;
                ventasOK.push({ ...c, subtotal, envio, descuento, total });
                totalVentas += total;
            } else {
                ventasError.push(c);
            }
        });
        resolve({ ventasOK, ventasError, totalVentas });
    });
}

module.exports = { procesarCarritos };