// EJERCICIO 9 – Reservas de Hotel
function procesarReservas(reservas) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(reservas)) return reject('Datos inválidos');
        let reservasProcesadas = [];
        let ingresosTotales = 0;
        reservas.forEach(r => {
            if (r.noches > 0) {
                let subtotal = r.noches * r.precioNoche;
                let impuesto = subtotal * 0.10;
                let descuento = r.noches > 5 ? subtotal * 0.15 : 0;
                let total = subtotal + impuesto - descuento;
                reservasProcesadas.push({ ...r, subtotal, impuesto, descuento, total });
                ingresosTotales += total;
            }
        });
        resolve({ reservasProcesadas, ingresosTotales });
    });
}

module.exports = { procesarReservas };