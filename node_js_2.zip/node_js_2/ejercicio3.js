// EJERCICIO 3 – Sistema de Calificaciones
function procesarCalificaciones(estudiantes) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(estudiantes)) return reject('Datos inválidos');
        let listaProcesada = [];
        let totalAprobados = 0;
        let totalReprobados = 0;
        estudiantes.forEach(e => {
            if (e.notas && e.notas.length > 0) {
                let promedio = e.notas.reduce((a, b) => a + b, 0) / e.notas.length;
                let aprobado = promedio >= 3;
                listaProcesada.push({ ...e, promedio, aprobado });
                if (aprobado) totalAprobados++;
                else totalReprobados++;
            } else {
                listaProcesada.push({ ...e, promedio: null, aprobado: false });
                totalReprobados++;
            }
        });
        resolve({ listaProcesada, totalAprobados, totalReprobados });
    });
}

module.exports = { procesarCalificaciones };