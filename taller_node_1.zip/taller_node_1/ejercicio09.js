// ============================================================
// TALLER I – Ejercicio 09: Generar Factura
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function generarFactura(productos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!Array.isArray(productos) || productos.length === 0) {
                reject(new Error("Error: No hay productos para facturar."));
                return;
            }
            const IVA = 0.19;
            const subtotal = productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
            const iva = subtotal * IVA;
            const total = subtotal + iva;
            resolve({
                productos,
                subtotal: subtotal.toFixed(2),
                iva: iva.toFixed(2),
                total: total.toFixed(2),
            });
        }, 1000);
    });
}

const carrito = [
    { nombre: "Laptop", precio: 3500000, cantidad: 1 },
    { nombre: "Mouse", precio: 50000, cantidad: 2 },
    { nombre: "Teclado", precio: 120000, cantidad: 1 },
];

console.log("── VERSIÓN PROMESAS ──");
generarFactura(carrito)
    .then((factura) => {
        console.log("📄 FACTURA:");
        factura.productos.forEach((p) =>
            console.log(`  ${p.nombre} x${p.cantidad} → $${(p.precio * p.cantidad).toLocaleString()}`)
        );
        console.log(`  Subtotal : $${factura.subtotal}`);
        console.log(`  IVA 19%  : $${factura.iva}`);
        console.log(`  TOTAL    : $${factura.total}`);
    })
    .catch((err) => console.error(err.message));

generarFactura([])
    .then((f) => console.log(f))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function procesarFactura(productos) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const factura = await generarFactura(productos);
        console.log("📄 FACTURA:");
        factura.productos.forEach((p) =>
            console.log(`  ${p.nombre} x${p.cantidad} → $${(p.precio * p.cantidad).toLocaleString()}`)
        );
        console.log(`  Subtotal : $${factura.subtotal}`);
        console.log(`  IVA 19%  : $${factura.iva}`);
        console.log(`  TOTAL    : $${factura.total}`);
    } catch (err) {
        console.error(err.message);
    }
}

procesarFactura(carrito);
procesarFactura([]);
