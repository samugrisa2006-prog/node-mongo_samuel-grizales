// ============================================================
// TALLER I – Ejercicio 11: Flujo de Compra Completo
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── FUNCIÓN AUXILIARES ──────────────────────────────────────
function validarUsuario(usuario, contrasena) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            usuario === "admin" && contrasena === "1234"
                ? resolve({ nombre: "Administrador" })
                : reject(new Error("❌ Credenciales inválidas."));
        }, 500);
    });
}

function validarStock(cantidad, stock) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            cantidad <= stock
                ? resolve(`Stock OK: ${cantidad} unidades disponibles.`)
                : reject(new Error(`❌ Stock insuficiente: solicitado ${cantidad}, disponible ${stock}.`));
        }, 500);
    });
}

function calcularTotal(productos) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const subtotal = productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
            resolve({ subtotal, iva: subtotal * 0.19, total: subtotal * 1.19 });
        }, 500);
    });
}

function confirmarCompra(datos) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const id = `ORD-${Date.now()}`;
            resolve(`✅ Compra confirmada. Pedido ${id}. Total: $${datos.total.toFixed(2)}`);
        }, 500);
    });
}

const carritoCompra = [
    { nombre: "Laptop", precio: 3500000, cantidad: 1 },
    { nombre: "Mouse", precio: 50000, cantidad: 2 },
];

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
console.log("── VERSIÓN PROMESAS ──");
validarUsuario("admin", "1234")
    .then(() => validarStock(3, 10))
    .then(() => calcularTotal(carritoCompra))
    .then((datos) => confirmarCompra(datos))
    .then((confirmacion) => console.log(confirmacion))
    .catch((err) => console.error(err.message));

// Caso de error: stock insuficiente
validarUsuario("admin", "1234")
    .then(() => validarStock(20, 10))
    .then(() => calcularTotal(carritoCompra))
    .then((datos) => confirmarCompra(datos))
    .then((confirmacion) => console.log(confirmacion))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function flujoCompraCompleto(usuario, contrasena, cantidad, stock, productos) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        await validarUsuario(usuario, contrasena);
        console.log("1️⃣  Usuario validado");
        await validarStock(cantidad, stock);
        console.log("2️⃣  Stock validado");
        const totales = await calcularTotal(productos);
        console.log(`3️⃣  Total calculado: $${totales.total.toFixed(2)}`);
        const confirmacion = await confirmarCompra(totales);
        console.log(`4️⃣  ${confirmacion}`);
    } catch (err) {
        console.error("🚫 Error en el flujo de compra:", err.message);
    }
}

flujoCompraCompleto("admin", "1234", 2, 10, carritoCompra);
flujoCompraCompleto("hacker", "9999", 2, 10, carritoCompra);
