// ============================================================
// TALLER I – Ejercicio 03: Conversión de Moneda
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function convertirMoneda(valor, tasa) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (typeof valor !== "number" || typeof tasa !== "number") {
                reject(new Error("Error: Los parámetros deben ser numéricos."));
                return;
            }
            if (tasa <= 0) {
                reject(new Error("Error: La tasa de cambio debe ser mayor a cero."));
                return;
            }
            const resultado = (valor * tasa).toFixed(2);
            resolve(`${valor} USD equivale a ${resultado} COP`);
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
convertirMoneda(100, 4200)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

convertirMoneda(50, -1)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function realizarConversion(valor, tasa) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const resultado = await convertirMoneda(valor, tasa);
        console.log(resultado);
    } catch (err) {
        console.error(err.message);
    }
}

realizarConversion(200, 4200);
realizarConversion(300, 0);
