// ============================================================
// TALLER I – Ejercicio 10: Validar Stock
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function validarStock(cantidadSolicitada, stockDisponible) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (cantidadSolicitada <= 0) {
                reject(new Error("Error: La cantidad solicitada debe ser mayor a cero."));
                return;
            }
            if (cantidadSolicitada > stockDisponible) {
                reject(
                    new Error(
                        `Stock insuficiente ❌: solicitado ${cantidadSolicitada}, disponible ${stockDisponible}.`
                    )
                );
            } else {
                resolve(
                    `Compra aprobada ✅: ${cantidadSolicitada} unidad(es) reservada(s). Stock restante: ${stockDisponible - cantidadSolicitada}.`
                );
            }
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
validarStock(3, 10)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

validarStock(15, 10)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

validarStock(0, 10)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function verificarStock(cantidadSolicitada, stockDisponible) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const resultado = await validarStock(cantidadSolicitada, stockDisponible);
        console.log(resultado);
    } catch (err) {
        console.error(err.message);
    }
}

verificarStock(5, 20);
verificarStock(25, 20);
