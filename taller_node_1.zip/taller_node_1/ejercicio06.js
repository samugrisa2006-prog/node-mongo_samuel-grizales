// ============================================================
// TALLER I – Ejercicio 06: Filtrar Productos por Precio
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

const productos = [
    { nombre: "Laptop", precio: 3500000 },
    { nombre: "Mouse", precio: 50000 },
    { nombre: "Teclado", precio: 120000 },
    { nombre: "Monitor", precio: 900000 },
    { nombre: "Audífonos", precio: 250000 },
    { nombre: "Webcam", precio: 180000 },
];

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function filtrarPorPrecio(lista, precioMinimo) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!Array.isArray(lista) || lista.length === 0) {
                reject(new Error("Error: La lista de productos está vacía o no es válida."));
                return;
            }
            const filtrados = lista.filter((p) => p.precio > precioMinimo);
            if (filtrados.length === 0) {
                reject(new Error(`No hay productos con precio mayor a $${precioMinimo.toLocaleString()}.`));
            } else {
                resolve(filtrados);
            }
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
filtrarPorPrecio(productos, 200000)
    .then((res) => {
        console.log(`Productos con precio > $200.000:`);
        res.forEach((p) => console.log(`  - ${p.nombre}: $${p.precio.toLocaleString()}`));
    })
    .catch((err) => console.error(err.message));

filtrarPorPrecio(productos, 5000000)
    .then((res) => console.log(res))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function buscarProductosCaros(lista, precioMinimo) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const resultado = await filtrarPorPrecio(lista, precioMinimo);
        console.log(`Productos con precio > $${precioMinimo.toLocaleString()}:`);
        resultado.forEach((p) => console.log(`  - ${p.nombre}: $${p.precio.toLocaleString()}`));
    } catch (err) {
        console.error(err.message);
    }
}

buscarProductosCaros(productos, 100000);
buscarProductosCaros(productos, 10000000);
