// ============================================================
// TALLER I – Ejercicio 07: Calcular Promedio de Notas
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function calcularPromedio(notas) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!Array.isArray(notas) || notas.length === 0) {
                reject(new Error("Error: El arreglo de notas está vacío o no es válido."));
                return;
            }
            const invalidas = notas.filter((n) => typeof n !== "number" || n < 0 || n > 10);
            if (invalidas.length > 0) {
                reject(new Error(`Error: Hay notas inválidas (deben ser entre 0 y 10): ${invalidas}`));
                return;
            }
            const suma = notas.reduce((acc, n) => acc + n, 0);
            const promedio = (suma / notas.length).toFixed(2);
            resolve({ promedio, aprobado: promedio >= 6, notas });
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
calcularPromedio([7, 8, 5, 9, 6])
    .then((res) => {
        console.log(`Notas: [${res.notas}]`);
        console.log(`Promedio: ${res.promedio}`);
        console.log(res.aprobado ? "Estado: Aprobado ✅" : "Estado: Reprobado ❌");
    })
    .catch((err) => console.error(err.message));

calcularPromedio([])
    .then((res) => console.log(res))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function evaluarNotas(notas) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const res = await calcularPromedio(notas);
        console.log(`Notas: [${res.notas}]`);
        console.log(`Promedio: ${res.promedio}`);
        console.log(res.aprobado ? "Estado: Aprobado ✅" : "Estado: Reprobado ❌");
    } catch (err) {
        console.error(err.message);
    }
}

evaluarNotas([4, 3, 5, 6, 2]);
evaluarNotas([10, 11, 8]);
