// ============================================================
// TALLER I – Ejercicio 01: Calculadora Avanzada
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function operar(a, b, tipo) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      switch (tipo) {
        case "suma":
          resolve(`Resultado: ${a + b}`);
          break;
        case "resta":
          resolve(`Resultado: ${a - b}`);
          break;
        case "multiplicacion":
          resolve(`Resultado: ${a * b}`);
          break;
        case "division":
          if (b === 0) {
            reject(new Error("Error: No se puede dividir por cero."));
          } else {
            resolve(`Resultado: ${a / b}`);
          }
          break;
        default:
          reject(new Error(`Error: Operación "${tipo}" no válida.`));
      }
    }, 1000);
  });
}

console.log("── VERSIÓN PROMESAS ──");
operar(10, 2, "suma")
  .then((res) => console.log(res))
  .catch((err) => console.error(err.message));

operar(10, 2, "resta")
  .then((res) => console.log(res))
  .catch((err) => console.error(err.message));

operar(10, 2, "multiplicacion")
  .then((res) => console.log(res))
  .catch((err) => console.error(err.message));

operar(10, 2, "division")
  .then((res) => console.log(res))
  .catch((err) => console.error(err.message));

operar(10, 0, "division")
  .then((res) => console.log(res))
  .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function ejecutarCalculadora() {
  console.log("\n── VERSIÓN ASYNC/AWAIT ──");
  try {
    console.log(await operar(20, 5, "suma"));
    console.log(await operar(20, 5, "resta"));
    console.log(await operar(20, 5, "multiplicacion"));
    console.log(await operar(20, 5, "division"));
    console.log(await operar(20, 0, "division")); // Provocará error
  } catch (err) {
    console.error(err.message);
  }
}

ejecutarCalculadora();
