// ============================================================
// TALLER I – Ejercicio 08: Buscar Usuario por ID
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// Simulación de base de datos
const baseDeDatos = [
    { id: 1, nombre: "Ana", email: "ana@correo.com" },
    { id: 2, nombre: "Luis", email: "luis@correo.com" },
    { id: 3, nombre: "María", email: "maria@correo.com" },
    { id: 4, nombre: "Carlos", email: "carlos@correo.com" },
];

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function buscarUsuarioPorId(id) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const usuario = baseDeDatos.find((u) => u.id === id);
            if (usuario) {
                resolve(usuario);
            } else {
                reject(new Error(`Error: No se encontró ningún usuario con ID ${id}.`));
            }
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
buscarUsuarioPorId(2)
    .then((u) => console.log(`Usuario encontrado: ${u.nombre} (${u.email})`))
    .catch((err) => console.error(err.message));

buscarUsuarioPorId(99)
    .then((u) => console.log(u))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function obtenerUsuario(id) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const usuario = await buscarUsuarioPorId(id);
        console.log(`Usuario encontrado: ${usuario.nombre} (${usuario.email})`);
    } catch (err) {
        console.error(err.message);
    }
}

obtenerUsuario(1);
obtenerUsuario(50);
