// ============================================================
// TALLER I – Ejercicio 12: Flujo de Préstamo Bancario
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── FUNCIONES AUXILIARES ────────────────────────────────────
function validarIngresos(ingresosMensuales, montoSolicitado) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // El cupo máximo es 5 veces el ingreso mensual
            const cupoMaximo = ingresosMensuales * 5;
            if (montoSolicitado <= cupoMaximo) {
                resolve(`Ingresos validados ✅. Cupo disponible: $${cupoMaximo.toLocaleString()}`);
            } else {
                reject(
                    new Error(
                        `❌ Ingresos insuficientes. Cupo máximo $${cupoMaximo.toLocaleString()}, solicitado $${montoSolicitado.toLocaleString()}.`
                    )
                );
            }
        }, 700);
    });
}

function validarHistorialCrediticio(puntaje) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (puntaje >= 650) {
                resolve(`Historial crediticio aprobado ✅. Puntaje: ${puntaje}`);
            } else {
                reject(
                    new Error(
                        `❌ Historial crediticio insuficiente. Puntaje: ${puntaje} (mínimo 650).`
                    )
                );
            }
        }, 700);
    });
}

function aprobarPrestamo(monto, plazoMeses) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const tasaMensual = 0.015; // 1.5% mensual
            const cuota = (monto * tasaMensual) / (1 - Math.pow(1 + tasaMensual, -plazoMeses));
            resolve({
                mensaje: "🏦 Préstamo aprobado ✅",
                monto,
                plazo: plazoMeses,
                cuotaMensual: cuota.toFixed(2),
            });
        }, 700);
    });
}

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
console.log("── VERSIÓN PROMESAS ──");
validarIngresos(3000000, 10000000)
    .then((msg) => {
        console.log(msg);
        return validarHistorialCrediticio(720);
    })
    .then((msg) => {
        console.log(msg);
        return aprobarPrestamo(10000000, 36);
    })
    .then((aprobacion) => {
        console.log(aprobacion.mensaje);
        console.log(`  Monto: $${aprobacion.monto.toLocaleString()} | Plazo: ${aprobacion.plazo} meses | Cuota: $${aprobacion.cuotaMensual}`);
    })
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function flujoPrestamoAsync(ingresos, monto, puntaje, plazo) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const msgIngresos = await validarIngresos(ingresos, monto);
        console.log("1️⃣ ", msgIngresos);
        const msgHistorial = await validarHistorialCrediticio(puntaje);
        console.log("2️⃣ ", msgHistorial);
        const aprobacion = await aprobarPrestamo(monto, plazo);
        console.log(`3️⃣  ${aprobacion.mensaje} – Cuota mensual: $${aprobacion.cuotaMensual}`);
    } catch (err) {
        console.error("🚫 Préstamo rechazado:", err.message);
    }
}

flujoPrestamoAsync(3000000, 10000000, 720, 36); // Aprobado
flujoPrestamoAsync(1000000, 10000000, 720, 36); // Rechazado por ingresos
flujoPrestamoAsync(3000000, 10000000, 500, 36); // Rechazado por historial
