// ============================================================
// TALLER I – Ejercicio 13: Registro de Estudiante
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── FUNCIONES AUXILIARES ────────────────────────────────────
function validarDatosEstudiante(estudiante) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const { nombre, edad, email, programa } = estudiante;
            if (!nombre || !email || !programa) {
                reject(new Error("❌ Nombre, email y programa son obligatorios."));
                return;
            }
            if (edad < 15 || edad > 80) {
                reject(new Error(`❌ Edad inválida (${edad}). Debe estar entre 15 y 80 años.`));
                return;
            }
            if (!email.includes("@")) {
                reject(new Error(`❌ Email inválido: ${email}`));
                return;
            }
            resolve({ ...estudiante, validado: true });
        }, 600);
    });
}

function guardarEstudiante(estudiante) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const matricula = `MAT-${Math.floor(Math.random() * 90000) + 10000}`;
            resolve({ ...estudiante, matricula, fechaRegistro: new Date().toLocaleDateString() });
        }, 600);
    });
}

function mostrarConfirmacion(estudiante) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(
                `✅ Registro exitoso:\n` +
                `   Nombre   : ${estudiante.nombre}\n` +
                `   Programa : ${estudiante.programa}\n` +
                `   Matrícula: ${estudiante.matricula}\n` +
                `   Fecha    : ${estudiante.fechaRegistro}`
            );
        }, 400);
    });
}

const nuevoEstudiante = { nombre: "Laura Gómez", edad: 22, email: "laura@correo.com", programa: "Ingeniería de Sistemas" };
const estudianteInvalido = { nombre: "", edad: 22, email: "sinAt", programa: "" };

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
console.log("── VERSIÓN PROMESAS ──");
validarDatosEstudiante(nuevoEstudiante)
    .then((est) => guardarEstudiante(est))
    .then((est) => mostrarConfirmacion(est))
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

validarDatosEstudiante(estudianteInvalido)
    .then((est) => guardarEstudiante(est))
    .then((est) => mostrarConfirmacion(est))
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function registrarEstudiante(estudiante) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const validado = await validarDatosEstudiante(estudiante);
        console.log("1️⃣  Datos validados");
        const guardado = await guardarEstudiante(validado);
        console.log("2️⃣  Estudiante guardado en base de datos");
        const confirmacion = await mostrarConfirmacion(guardado);
        console.log("3️⃣ ", confirmacion);
    } catch (err) {
        console.error("🚫 Error en registro:", err.message);
    }
}

registrarEstudiante(nuevoEstudiante);
registrarEstudiante(estudianteInvalido);
