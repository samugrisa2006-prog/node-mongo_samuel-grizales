// ============================================================
// TALLER I – Ejercicio 04: Validar Usuario
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function validarUsuario(usuario, contrasena) {
    const USUARIO_CORRECTO = "admin";
    const CONTRASENA_CORRECTA = "1234";

    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (usuario === USUARIO_CORRECTO && contrasena === CONTRASENA_CORRECTA) {
                resolve({ ok: true, mensaje: "Usuario validado correctamente ✅" });
            } else {
                reject(new Error("Credenciales incorrectas ❌"));
            }
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
validarUsuario("admin", "1234")
    .then((res) => console.log(res.mensaje))
    .catch((err) => console.error(err.message));

validarUsuario("admin", "wrongPass")
    .then((res) => console.log(res.mensaje))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function autenticar(usuario, contrasena) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const resultado = await validarUsuario(usuario, contrasena);
        console.log(resultado.mensaje);
    } catch (err) {
        console.error(err.message);
    }
}

autenticar("admin", "1234");
autenticar("root", "5678");
