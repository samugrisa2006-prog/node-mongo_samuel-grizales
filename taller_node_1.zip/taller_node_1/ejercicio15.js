// ============================================================
// TALLER I – Ejercicio 15: Flujo Empresarial Completo
// Simulación de backend: Autenticación → Datos → Procesamiento → Respuesta
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── FUNCIONES AUXILIARES ────────────────────────────────────

/** Paso 1: Autenticación */
function autenticar(usuario, contrasena) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const USUARIOS_DB = { admin: "1234", gerente: "abcd", analista: "pass" };
            if (USUARIOS_DB[usuario] && USUARIOS_DB[usuario] === contrasena) {
                const token = `TOKEN-${usuario.toUpperCase()}-${Date.now()}`;
                resolve({ usuario, token, rol: usuario });
            } else {
                reject(new Error(`❌ Autenticación fallida: usuario o contraseña incorrectos.`));
            }
        }, 500);
    });
}

/** Paso 2: Obtener datos del servidor */
function obtenerDatos(token) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!token || !token.startsWith("TOKEN-")) {
                reject(new Error("❌ Token inválido. Acceso no autorizado."));
                return;
            }
            const datos = {
                reportes: [
                    { mes: "Noviembre", ventas: 85000000 },
                    { mes: "Diciembre", ventas: 120000000 },
                    { mes: "Enero", ventas: 96000000 },
                ],
                totalEmpleados: 45,
                region: "Bogotá",
            };
            resolve(datos);
        }, 600);
    });
}

/** Paso 3: Procesar los datos obtenidos */
function procesarDatos(datos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!datos || !datos.reportes || datos.reportes.length === 0) {
                reject(new Error("❌ No hay datos para procesar."));
                return;
            }
            const totalVentas = datos.reportes.reduce((acc, r) => acc + r.ventas, 0);
            const promedioVentas = totalVentas / datos.reportes.length;
            const mejorMes = datos.reportes.reduce((a, b) => (a.ventas > b.ventas ? a : b));
            resolve({
                totalVentas,
                promedioVentas: promedioVentas.toFixed(2),
                mejorMes: mejorMes.mes,
                ventasMejorMes: mejorMes.ventas,
                totalEmpleados: datos.totalEmpleados,
                region: datos.region,
            });
        }, 600);
    });
}

/** Paso 4: Generar respuesta final */
function generarRespuesta(procesado, usuario) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                status: 200,
                usuario,
                timestamp: new Date().toISOString(),
                resumen: {
                    region: procesado.region,
                    totalVentas: `$${procesado.totalVentas.toLocaleString()}`,
                    promedioMensual: `$${Number(procesado.promedioVentas).toLocaleString()}`,
                    mejorMes: `${procesado.mejorMes} ($${procesado.ventasMejorMes.toLocaleString()})`,
                    empleados: procesado.totalEmpleados,
                },
            });
        }, 400);
    });
}

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
console.log("── VERSIÓN PROMESAS ──");
let usuarioAutenticado;
autenticar("admin", "1234")
    .then((auth) => {
        usuarioAutenticado = auth.usuario;
        console.log(`1️⃣  Autenticado: ${auth.usuario} | Token: ${auth.token}`);
        return obtenerDatos(auth.token);
    })
    .then((datos) => {
        console.log(`2️⃣  Datos obtenidos: ${datos.reportes.length} reportes de ${datos.region}`);
        return procesarDatos(datos);
    })
    .then((procesado) => {
        console.log(`3️⃣  Procesamiento completado. Mejor mes: ${procesado.mejorMes}`);
        return generarRespuesta(procesado, usuarioAutenticado);
    })
    .then((respuesta) => {
        console.log("4️⃣  Respuesta final generada:");
        console.log("   Status     :", respuesta.status);
        console.log("   Usuario    :", respuesta.usuario);
        console.log("   Región     :", respuesta.resumen.region);
        console.log("   Ventas     :", respuesta.resumen.totalVentas);
        console.log("   Promedio   :", respuesta.resumen.promedioMensual);
        console.log("   Mejor mes  :", respuesta.resumen.mejorMes);
        console.log("   Empleados  :", respuesta.resumen.empleados);
        console.log("   Timestamp  :", respuesta.timestamp);
    })
    .catch((err) => console.error("🚫 Error en flujo empresarial:", err.message));

// Caso de error: credenciales incorrectas
autenticar("intruso", "hackeo")
    .then((auth) => obtenerDatos(auth.token))
    .then((datos) => procesarDatos(datos))
    .then((procesado) => generarRespuesta(procesado, "intruso"))
    .then((res) => console.log(res))
    .catch((err) => console.error("🚫 Acceso rechazado:", err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function flujoEmpresarial(usuario, contrasena) {
    console.log(`\n── VERSIÓN ASYNC/AWAIT (${usuario}) ──`);
    try {
        // Paso 1: Autenticación
        const auth = await autenticar(usuario, contrasena);
        console.log(`1️⃣  Autenticado: ${auth.usuario} | Token: ${auth.token}`);

        // Paso 2: Obtener datos
        const datos = await obtenerDatos(auth.token);
        console.log(`2️⃣  Datos obtenidos: ${datos.reportes.length} reportes, región ${datos.region}`);

        // Paso 3: Procesar datos
        const procesado = await procesarDatos(datos);
        console.log(`3️⃣  Total ventas: $${procesado.totalVentas.toLocaleString()} | Mejor mes: ${procesado.mejorMes}`);

        // Paso 4: Respuesta final
        const respuesta = await generarRespuesta(procesado, auth.usuario);
        console.log("4️⃣  ✅ Respuesta final:");
        console.log(JSON.stringify(respuesta.resumen, null, 4));
        return respuesta;
    } catch (err) {
        // Manejo centralizado de errores
        console.error(`🚫 Error en flujo [${usuario}]:`, err.message);
    }
}

flujoEmpresarial("gerente", "abcd");
flujoEmpresarial("desconocido", "---");
