// ============================================================
// TALLER I – Ejercicio 05: Simulación de Login + Mensaje
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── FUNCIONES BASE ──────────────────────────────────────────
function validarUsuario(usuario, contrasena) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (usuario === "admin" && contrasena === "1234") {
                resolve({ nombre: "Administrador", rol: "admin" });
            } else {
                reject(new Error("Credenciales incorrectas. Login fallido ❌"));
            }
        }, 1000);
    });
}

function mostrarBienvenida(datosUsuario) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`🎉 ¡Bienvenido, ${datosUsuario.nombre}! Tu rol es: ${datosUsuario.rol}.`);
        }, 500);
    });
}

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
console.log("── VERSIÓN PROMESAS ──");
validarUsuario("admin", "1234")
    .then((datos) => mostrarBienvenida(datos))
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

validarUsuario("hacker", "0000")
    .then((datos) => mostrarBienvenida(datos))
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function flujoLogin(usuario, contrasena) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const datos = await validarUsuario(usuario, contrasena);
        const mensaje = await mostrarBienvenida(datos);
        console.log(mensaje);
    } catch (err) {
        console.error(err.message);
    }
}

flujoLogin("admin", "1234");
flujoLogin("guest", "9999");
