// ============================================================
// TALLER I – Ejercicio 14: Procesamiento de Pedido
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── FUNCIONES AUXILIARES ────────────────────────────────────
function generarIdPedido() {
    return new Promise((resolve) => {
        setTimeout(() => {
            const id = `PED-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
            resolve(id);
        }, 500);
    });
}

function calcularTotalPedido(productos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!productos || productos.length === 0) {
                reject(new Error("❌ El pedido no tiene productos."));
                return;
            }
            const subtotal = productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
            const iva = subtotal * 0.19;
            resolve({ subtotal, iva, total: subtotal + iva });
        }, 500);
    });
}

function simularEnvio(idPedido, total) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const fechaEntrega = new Date();
            fechaEntrega.setDate(fechaEntrega.getDate() + 3);
            resolve({
                idPedido,
                totalPagado: total.toFixed(2),
                estado: "En camino 🚚",
                fechaEntrega: fechaEntrega.toLocaleDateString(),
            });
        }, 600);
    });
}

const pedido = [
    { nombre: "Camisa", precio: 80000, cantidad: 2 },
    { nombre: "Jeans", precio: 150000, cantidad: 1 },
];

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
console.log("── VERSIÓN PROMESAS ──");
let pedidoId;
generarIdPedido()
    .then((id) => {
        pedidoId = id;
        console.log(`1️⃣  ID generado: ${id}`);
        return calcularTotalPedido(pedido);
    })
    .then((totales) => {
        console.log(`2️⃣  Total: $${totales.total.toFixed(2)} (IVA: $${totales.iva.toFixed(2)})`);
        return simularEnvio(pedidoId, totales.total);
    })
    .then((envio) => {
        console.log(`3️⃣  Estado: ${envio.estado} | Entrega estimada: ${envio.fechaEntrega}`);
        console.log(`✅ Pedido ${envio.idPedido} confirmado por $${envio.totalPagado}`);
    })
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function procesarPedido(productos) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const id = await generarIdPedido();
        console.log(`1️⃣  ID generado: ${id}`);
        const totales = await calcularTotalPedido(productos);
        console.log(`2️⃣  Total: $${totales.total.toFixed(2)} (IVA: $${totales.iva.toFixed(2)})`);
        const envio = await simularEnvio(id, totales.total);
        console.log(`3️⃣  Estado: ${envio.estado} | Entrega: ${envio.fechaEntrega}`);
        console.log(`✅ Pedido ${envio.idPedido} confirmado por $${envio.totalPagado}`);
    } catch (err) {
        console.error("🚫 Error en pedido:", err.message);
    }
}

procesarPedido(pedido);
procesarPedido([]); // Generará error en calcularTotal
