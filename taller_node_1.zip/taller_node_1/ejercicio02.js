// ============================================================
// TALLER I – Ejercicio 02: Validación de Edad
// Ficha: 3287352 | Instructor: César A. Moreno
// ============================================================

// ─── VERSIÓN PROMESAS ────────────────────────────────────────
function validarEdad(edad) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (edad >= 18) {
                resolve("Acceso permitido ✅");
            } else {
                reject(new Error(`Acceso denegado ❌: La edad ${edad} es menor de 18 años.`));
            }
        }, 1000);
    });
}

console.log("── VERSIÓN PROMESAS ──");
validarEdad(20)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

validarEdad(15)
    .then((msg) => console.log(msg))
    .catch((err) => console.error(err.message));

// ─── VERSIÓN ASYNC/AWAIT ─────────────────────────────────────
async function verificarAcceso(edad) {
    console.log("\n── VERSIÓN ASYNC/AWAIT ──");
    try {
        const resultado = await validarEdad(edad);
        console.log(resultado);
    } catch (err) {
        console.error(err.message);
    }
}

verificarAcceso(25);
verificarAcceso(12);
